import React from 'react';
import CardList from './CardList.js';
import './App.css';

export default function App() {
  return(
    <div>
      <CardList/>
    </div>
  );
}